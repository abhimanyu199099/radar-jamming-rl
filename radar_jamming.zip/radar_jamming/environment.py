import numpy as np
import math
import torch
import matplotlib.pyplot as plt
import gymnasium as gym
from gym import Env
from gym import spaces
import random
from IPython.display import clear_output
import os
import matplotlib
from collections import namedtuple, deque
from itertools import count
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from pettingzoo import ParallelEnv
import seaborn as sns

is_ipython = 'inline' in matplotlib.get_backend()
if is_ipython:
    from IPython import display

plt.ion()

#device setup
device = torch.device(
    "cuda" if torch.cuda.is_available() else
    "mps" if torch.backends.mps.is_available() else
    "cpu"
)

class ParallelRadarJammingEnv(ParallelEnv):
    def __init__(self, hop_states, jamming_bandwidths, max_hop_length=8):
        super().__init__()

        self.hop_states = hop_states
        self.max_hop_length = max_hop_length

        #params for each hop state list
        self.low = [hop[0] for hop in self.hop_states]
        self.interval = [hop[1] - hop[0] for hop in self.hop_states]
        self.n_frequencies = [len(hop) for hop in self.hop_states]

        #agents
        self.agents = ["jammer_0", "jammer_1", "jammer_2", "jammer_3", "jammer_4", "jammer_5"]
        self.possible_agents = self.agents[:]
        self.agent_name_mapping = {agent: i for i, agent in enumerate(self.agents)}

        #action space
        self.jamming_bandwidths = jamming_bandwidths    
        self.n_bandwidths = len(self.jamming_bandwidths)
        self.action_space = {agent: spaces.Discrete(self.max_hop_length * self.n_bandwidths) for agent in self.agents}

        #observation space
        self.observation_spaces = {
            agent: spaces.Box(low=0, high=1, shape=(sum(self.n_frequencies),), dtype=np.float32) for agent in self.agents
        }

        self.hopping_patterns = None
        self.current_frequencies = None
        self.current_steps = None
        self.cumulative_rewards = None
        self.net_agent_rewards = None
        self.terminations = None
        self.rewards = None
        self.info = None

        
        #jamming fractions
        self.jamming_fractions = None
        self.episode_jamming_success = np.zeros((len(self.hop_states), 200))

    def index_to_action(self, index):
        #action index to freq + bandwidth
        frequency_index = index // self.n_bandwidths
        bandwidth_index = index % self.n_bandwidths
        hop_index = frequency_index % len(self.hop_states)
        frequency = int(self.low[hop_index] + (frequency_index // len(self.hop_states)) * self.interval[hop_index])
        bandwidth = self.jamming_bandwidths[bandwidth_index]
        return frequency, bandwidth

    def generate_hopping_pattern(self):
        return [np.random.choice(hop, self.max_hop_length, replace=False) for hop in self.hop_states]

    def reset(self):
        self.hopping_patterns = self.generate_hopping_pattern()

        # select two unique, non-overlapping frequencies from each pattern
        self.radar_frequencies = [
            [pattern[0], pattern[1]] for pattern in self.hopping_patterns
        ]

        self.current_steps = {agent: 0 for agent in self.agents}
        self.cumulative_rewards = {agent: 0 for agent in self.agents}
        self.terminations = {agent: False for agent in self.agents}
        self.rewards = {agent: 0 for agent in self.agents}
        self.info = {agent: {} for agent in self.agents}

        observations = {agent: self.observe(agent) for agent in self.agents}
        return observations

    def observe(self, agent):
        # observation is a one-hot encoded vector representing the radar frequencies across all hop_states
        observation = np.zeros(sum(self.n_frequencies))
        offset = 0
        for i, frequencies in enumerate(self.hop_states):
            for radar_freq in self.radar_frequencies[i]:  # both frequencies are now represented
                freq_index = np.where(np.array(frequencies) == radar_freq)[0][0]
                observation[offset + freq_index] = 1
            offset += len(frequencies)
        return observation


    def step(self, actions):
        total_jammed_frequencies = 0
        self.net_agent_rewards = 0

        #jamming success rate
        jammed_array = np.zeros_like(self.radar_frequencies)

        for agent, action in actions.items():
            frequency, bandwidth = self.index_to_action(action)
            lower_bound = frequency - bandwidth
            upper_bound = frequency + bandwidth

            jammed = False

            for radar_frequencies in self.radar_frequencies:
                for radar_frequency in radar_frequencies:
                    if lower_bound <= radar_frequency <= upper_bound:
                        jammed = True
                        reward = 30 * ([np.where(np.array(hop) == frequency)[0][0] for hop in self.hop_states if frequency in hop][0] + 1)
                        total_jammed_frequencies += 1
                        #updating jammed array
                        jammed_array[self.radar_frequencies.index(radar_frequencies)][radar_frequencies.index(radar_frequency)] = 1


            if jammed == False:
                reward = -50
                
            for i in range(len(jammed_array)):
                if np.all(jammed_array[i] == 1):
                    self.episode_jamming_success[i][self.current_steps[agent]] = 1

            # if jammed the reward is 30 * (the element of hop_states that the frequency is found in + 1)

            hop_index = np.argmin([abs(frequency - radar[0]) for radar in self.radar_frequencies])

            if 2 * (bandwidth / self.interval[hop_index]) > 5:
                reward -= 10

            jam_threshold = len(self.hop_states[0]) / len(self.agents)
            if total_jammed_frequencies > jam_threshold:
                reward += 5
            else:
                reward -= 5
            
            self.current_steps[agent] += 1
            self.cumulative_rewards[agent] += reward
            self.net_agent_rewards += reward

            # Termination condition after 200 steps
            if self.current_steps[agent] >= 200:
                self.terminations[agent] = True

            self.rewards[agent] = reward

        # Update radar frequencies for the next step with no overlap between two frequencies
        self.radar_frequencies = [
            [
                pattern[self.current_steps[agent] % self.max_hop_length],  # first frequency
                pattern[(self.current_steps[agent] + 2) % self.max_hop_length]  # second frequency ensuring no overlap
            ]
            for pattern in self.hopping_patterns
        ]
        if all(self.terminations.values()):
            self.jamming_fractions = np.sum(self.episode_jamming_success, axis=1) / 200
        
        self.episode_jamming_success = np.zeros_like(self.episode_jamming_success)

        # Return observations, rewards, done status, and info for each agent
        observations = {agent: self.observe(agent) for agent in self.agents}
        rewards = {agent: self.rewards[agent] for agent in self.agents}
        done = {agent: self.terminations[agent] for agent in self.agents}
        info = {agent: self.info[agent] for agent in self.agents}

        return observations, rewards, done, info

    def render(self):
        for agent in self.agents:
            print(f"Agent {agent}, Step: {self.current_steps[agent]}, Radar Frequencies: {self.radar_frequencies}")
