from collections import deque, namedtuple
import numpy as np

Transition = namedtuple('Transition',
('state', 'action', 'next_state', 'reward')
)

class SequentialReplayBuffer:
    def __init__(self, maxlen=16000):
        self.buffer = deque(maxlen=maxlen)

    def append(self, trajectory):
        """Add a sequence of transitions to the buffer."""
        self.buffer.append(trajectory)

    def sample(self, batch_size, sequence_length):
        """Sample sequences of transitions."""
        if len(self.buffer) < batch_size:
            return []
        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        sampled = [self.buffer[idx] for idx in indices]
        return [self._pad_sequence(trajectory, sequence_length) for trajectory in sampled]

    @staticmethod
    def _pad_sequence(sequence, sequence_length):
        """Pad or truncate sequences to match `sequence_length`."""
        if len(sequence) >= sequence_length:
            return sequence[-sequence_length:]
        return [sequence[0]] * (sequence_length - len(sequence)) + sequence